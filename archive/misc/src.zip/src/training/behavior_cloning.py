"""Behavior cloning of the Transformer actor from exact-mask expert demos."""
from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from src.data.evrptw_dataset import split_dataset
from src.data.instance_loader import load_capacity_from_config
from src.data.training_phases import resolve_training_phase_split
from src.env.cost import CostWeights
from src.env.evrptw_env import EVRPTWEnv
from src.env.policy_action import PolicyAction, apply_policy_action
from src.expert.generate_demonstrations import run_expert_episode
from src.expert.feasibility_first_expert import FeasibilityFirstExpert
from src.models.policy import TransformerEVRPTWPolicy
from src.training.flat_schedule import sample_fleet_size
from src.training.train_rl import build_policy, load_policy
from src.utils.config import load_config
from src.utils.logging_utils import get_logger
from src.utils.seed import describe_device, resolve_device, set_seed
from src.utils.tensor_utils import safe_mask_logits

LOGGER = get_logger()


def _portion_index(portions: list[float], value: float) -> int:
    for i, p in enumerate(portions):
        if abs(float(p) - float(value)) < 1e-9:
            return i
    raise ValueError(f"charge portion {value} not in {portions}")


def masked_ce_from_logits(logits: torch.Tensor, target_idx: int, mask: torch.Tensor) -> torch.Tensor:
    """Cross-entropy on masked logits; never trains illegal actions."""
    masked = safe_mask_logits(logits, mask)
    log_probs = torch.log_softmax(masked, dim=-1)
    if not bool(mask[target_idx].item()):
        raise RuntimeError(f"BC target index {target_idx} is illegal under mask")
    return -log_probs[target_idx]


def bc_loss_on_decision(
    policy: TransformerEVRPTWPolicy,
    env: EVRPTWEnv,
    ev,
    analysis,
    node_embeddings: torch.Tensor,
    expert_action: PolicyAction,
) -> tuple[torch.Tensor, dict]:
    """Supervise node / charge / depot-mode heads for one decision."""
    mask_result = analysis.mask_result
    state = policy.build_decision_state(
        env, ev, node_embeddings, mask_result, analysis=analysis,
    )
    device = node_embeddings.device
    scores = policy.pointer.node_scores(
        state.decoder_context,
        state.candidate_embeddings,
        state.dynamic_candidate_embeddings,
    )
    node_mask = torch.tensor(state.feasible_mask, dtype=torch.bool, device=device)
    node_loss = masked_ce_from_logits(scores, int(expert_action.node), node_mask)

    charge_loss = torch.zeros((), device=device)
    depot_loss = torch.zeros((), device=device)
    stats = {
        "node_correct": 0.0,
        "charge_correct": 0.0,
        "depot_correct": 0.0,
        "charge_used": 0.0,
        "depot_used": 0.0,
        "illegal_target": 0.0,
    }
    with torch.no_grad():
        pred_node = int(torch.argmax(safe_mask_logits(scores, node_mask)).item())
        stats["node_correct"] = float(pred_node == int(expert_action.node))

    inst = env.instance
    node = int(expert_action.node)
    if inst.nodes[node].is_depot:
        ok_r = bool(mask_result.depot_mode_mask[0])
        ok_f = bool(mask_result.depot_mode_mask[1])
        if ok_r and ok_f:
            mode_logits = policy.pointer.depot_mode_logits(
                state.decoder_context,
                state.candidate_embeddings[node],
                state.global_context,
                state.mask_context,
            )
            dm = torch.tensor(mask_result.depot_mode_mask, device=device, dtype=torch.bool)
            target_mode = 1 if expert_action.depot_finish else 0
            depot_loss = masked_ce_from_logits(mode_logits, target_mode, dm)
            stats["depot_used"] = 1.0
            with torch.no_grad():
                pred = int(torch.argmax(safe_mask_logits(mode_logits, dm)).item())
                stats["depot_correct"] = float(pred == target_mode)
        if not expert_action.depot_finish and expert_action.charge_portion is not None:
            charge_loss, cstats = _charge_loss(
                policy, env, ev, state, node, float(expert_action.charge_portion),
            )
            stats.update(cstats)
    elif inst.nodes[node].is_charging_station:
        if expert_action.charge_portion is None:
            raise RuntimeError("Expert station action missing charge portion")
        charge_loss, cstats = _charge_loss(
            policy, env, ev, state, node, float(expert_action.charge_portion),
        )
        stats.update(cstats)

    loss = node_loss + 0.5 * charge_loss + 0.5 * depot_loss
    stats["node_loss"] = float(node_loss.detach())
    stats["charge_loss"] = float(charge_loss.detach())
    stats["depot_loss"] = float(depot_loss.detach())
    return loss, stats


def _charge_loss(policy, env, ev, state, station: int, portion: float):
    from src.models.state_features import battery_state_features

    device = state.decoder_context.device
    dtype = state.decoder_context.dtype
    batt = torch.tensor(battery_state_features(env, ev), device=device, dtype=dtype)
    logits = policy.pointer.charging_logits(
        state.decoder_context,
        state.candidate_embeddings[station],
        state.acting_ev_context,
        batt,
    )
    cm = state.mask_result.charge_masks[station]
    mask_t = torch.tensor(cm, device=device, dtype=torch.bool)
    idx = _portion_index(list(policy.charging_portions), portion)
    loss = masked_ce_from_logits(logits, idx, mask_t)
    stats = {"charge_used": 1.0, "charge_correct": 0.0}
    with torch.no_grad():
        pred = int(torch.argmax(safe_mask_logits(logits, mask_t)).item())
        stats["charge_correct"] = float(pred == idx)
    return loss, stats


def bc_loss_on_demo_batch(
    policy: TransformerEVRPTWPolicy,
    episodes: list[dict],
    instance_by_name: dict,
    *,
    device: torch.device,
    batch_episodes: int = 1,
    rng: random.Random | None = None,
) -> tuple[torch.Tensor, dict]:
    """Replay random demo episodes and accumulate masked CE."""
    rng = rng or random.Random(0)
    if not episodes:
        z = torch.zeros((), device=device)
        return z, {}
    chosen = [episodes[rng.randrange(len(episodes))] for _ in range(max(1, batch_episodes))]
    losses = []
    agg = {
        "node_correct": 0.0, "charge_correct": 0.0, "depot_correct": 0.0,
        "charge_used": 0.0, "depot_used": 0.0, "n": 0.0,
    }
    for ep in chosen:
        instance = instance_by_name[ep["instance_name"]]
        env = EVRPTWEnv(
            instance,
            m=int(ep["m"]),
            charging_portions=list(policy.charging_portions),
            use_horizon_check=True,
            use_depot_charging=True,
            hard_time_windows=True,
        )
        node_embeddings = policy.encode(instance, device=device)
        action_i = 0
        while not env.is_done() and action_i < len(ep["actions"]):
            ev = env.select_acting_ev()
            if ev is None:
                break
            analysis = env.analyze_decision(ev)
            if env.try_controlled_closure_from_analysis(ev, analysis) is not None:
                continue
            if env.try_auto_close_from_analysis(ev, analysis) is not None:
                continue
            a = ep["actions"][action_i]
            action_i += 1
            expert_action = PolicyAction(
                node=int(a["node"]),
                charge_portion=a.get("charge_portion"),
                depot_finish=bool(a.get("depot_finish", False)),
            )
            loss, stats = bc_loss_on_decision(
                policy, env, ev, analysis, node_embeddings, expert_action,
            )
            losses.append(loss)
            for k in ("node_correct", "charge_correct", "depot_correct", "charge_used", "depot_used"):
                agg[k] += float(stats.get(k, 0.0))
            agg["n"] += 1.0
            apply_policy_action(env, ev, expert_action, mask_result=analysis.mask_result)
    if not losses:
        z = torch.zeros((), device=device)
        return z, agg
    total = torch.stack(losses).mean()
    n = max(agg["n"], 1.0)
    metrics = {
        "bc_loss": float(total.detach()),
        "node_accuracy": agg["node_correct"] / n,
        "charge_accuracy": agg["charge_correct"] / max(agg["charge_used"], 1.0),
        "depot_accuracy": agg["depot_correct"] / max(agg["depot_used"], 1.0),
        "n_decisions": n,
    }
    return total, metrics


def evaluate_bc_policy(config: dict, policy: TransformerEVRPTWPolicy, device: torch.device) -> dict:
    """Greedy rollout of the cloned policy on train instances (compact report)."""
    train_names, eval_names, _ = resolve_training_phase_split(config)
    ds_cfg = dict(config["dataset"])
    train_ds, eval_ds = split_dataset(
        ds_cfg["path"],
        train_ratio=float(ds_cfg.get("train_ratio", 0.8)),
        seed=int(config.get("seed", 42)),
        train_filter=ds_cfg.get("train_size_filter") or ["_21"],
        eval_filter=ds_cfg.get("eval_size_filter") or ["_21"],
        train_instances=train_names,
        eval_instances=eval_names,
        class_filter=ds_cfg.get("class_filter"),
        load_capacity=load_capacity_from_config(config),
    )
    weights = CostWeights.from_config(config["cost"])
    extra_margin = int(config["fleet_search"].get("extra_margin", 4))
    max_steps_factor = int(config["decoding"].get("max_steps_factor", 6))
    use_horizon = bool(config["problem"].get("use_horizon_check", True))
    use_depot = bool(config["problem"].get("use_depot_charging", True))
    env_cfg = config.get("environment") or {}
    rng = random.Random(int(config.get("seed", 42)))
    policy.eval()
    rows = []
    # Evaluate on holdout preferentially.
    ds = eval_ds if len(eval_ds) else train_ds
    for i in range(len(ds)):
        instance = ds[i]
        m = sample_fleet_size(instance, extra_margin, rng)
        env = EVRPTWEnv(
            instance, m=m,
            charging_portions=list(policy.charging_portions),
            use_horizon_check=use_horizon,
            use_depot_charging=use_depot,
            max_steps_factor=max_steps_factor,
            hard_time_windows=True,
        )
        env.environment_config = env_cfg
        H = policy.encode(instance, device=device)
        while not env.is_done():
            ev = env.select_acting_ev()
            if ev is None:
                break
            analysis = env.analyze_decision(ev)
            if env.try_controlled_closure_from_analysis(ev, analysis) is not None:
                continue
            if env.try_auto_close_from_analysis(ev, analysis) is not None:
                continue
            with torch.no_grad():
                out = policy.select_action(
                    env, ev, H, analysis.mask_result, mode="greedy", analysis=analysis,
                )
            apply_policy_action(env, ev, out, mask_result=analysis.mask_result)
        for ev in env.evs:
            if not ev.finished:
                env.auto_close_route(ev, forced=True)
        j, _, summary = env.score(weights)
        cust_a = float(getattr(env, "customer_actions", 0))
        st_a = float(getattr(env, "station_actions", 0))
        dep_a = float(getattr(env, "depot_finish_count", 0)) + float(
            getattr(env, "depot_recharge_count", 0)
        )
        n_act = max(cust_a + st_a + dep_a, 1.0)
        rows.append({
            "instance_name": instance.instance_name,
            "served_ratio": env.num_served_customers / max(instance.num_customers, 1),
            "feasible": env.feasible_solution(),
            "objective": float(j),
            "unserved_customers": int(summary.unserved_customers),
            "battery_violations": int(env.battery_violation_count),
            "time_window_violations": int(env.time_window_violation_count),
            "max_step_terminations": int(bool(getattr(env, "max_steps_reached", False))),
            "depot_finish_count": float(getattr(env, "depot_finish_count", 0)),
            "station_action_fraction": float(st_a / n_act),
            "depot_lateness": float(summary.depot_return_violation),
        })
    n = max(len(rows), 1)
    report = {
        "num_instances": len(rows),
        "mean_served_ratio": float(sum(r["served_ratio"] for r in rows) / n),
        "feasibility_rate": float(sum(1 for r in rows if r["feasible"]) / n),
        "mean_objective": float(sum(r["objective"] for r in rows) / n),
        "mean_unserved": float(sum(r["unserved_customers"] for r in rows) / n),
        "mean_battery_violations": float(sum(r["battery_violations"] for r in rows) / n),
        "mean_tw_violations": float(sum(r["time_window_violations"] for r in rows) / n),
        "mean_max_steps": float(sum(r["max_step_terminations"] for r in rows) / n),
        "mean_depot_finish_count": float(sum(r["depot_finish_count"] for r in rows) / n),
        "mean_station_action_fraction": float(sum(r["station_action_fraction"] for r in rows) / n),
        "mean_depot_lateness": float(sum(r["depot_lateness"] for r in rows) / n),
        "per_instance": rows,
    }
    LOGGER.info(
        "BC greedy eval | served=%.3f feas=%.3f J=%.1f unserved=%.1f",
        report["mean_served_ratio"], report["feasibility_rate"],
        report["mean_objective"], report["mean_unserved"],
    )
    return report


def train_behavior_cloning(config: dict) -> dict:
    set_seed(int(config.get("seed", 42)), deterministic=bool(config.get("deterministic", False)))
    device = resolve_device(config.get("device", "auto"))
    LOGGER.info("BC training on %s", describe_device(device))

    demo_path = Path((config.get("demonstrations") or {}).get("input", "outputs/demonstrations/rc21_expert.pt"))
    if not demo_path.is_file():
        raise FileNotFoundError(
            f"Demonstration file not found: {demo_path}. "
            "Run: python -m src.expert.generate_demonstrations --config configs/expert_RC21.yaml"
        )
    payload = torch.load(demo_path, map_location="cpu", weights_only=False)
    episodes = list(payload["episodes"])
    LOGGER.info("Loaded %d demo episodes from %s", len(episodes), demo_path)

    train_names, eval_names, _ = resolve_training_phase_split(config)
    ds_cfg = dict(config["dataset"])
    train_ds, _eval_ds = split_dataset(
        ds_cfg["path"],
        train_ratio=float(ds_cfg.get("train_ratio", 0.8)),
        seed=int(config.get("seed", 42)),
        train_filter=ds_cfg.get("train_size_filter") or ["_21"],
        eval_filter=ds_cfg.get("eval_size_filter") or ["_21"],
        train_instances=train_names,
        eval_instances=eval_names,
        class_filter=ds_cfg.get("class_filter"),
        load_capacity=load_capacity_from_config(config),
    )
    instance_by_name = {n: train_ds[train_ds.names.index(n)] for n in train_ds.names}

    portions = list(config["problem"]["charging_portions"])
    policy = build_policy(config, portions).to(device)
    bcfg = config.get("behavior_cloning") or config.get("bc") or {}
    lr = float(bcfg.get("learning_rate", 1e-4))
    epochs = int(bcfg.get("epochs", 20))
    batch_episodes = int(bcfg.get("batch_episodes", 2))
    log_every = int(bcfg.get("log_every", 1))
    out_dir = Path(bcfg.get("output_dir", "outputs/bc"))
    out_dir.mkdir(parents=True, exist_ok=True)
    optimizer = torch.optim.Adam(policy.parameters(), lr=lr)
    rng = random.Random(int(config.get("seed", 42)))

    best_val = float("inf")
    best_path = out_dir / "rc21_best_policy.pt"
    history = []

    for epoch in range(epochs):
        policy.train()
        loss, metrics = bc_loss_on_demo_batch(
            policy, episodes, instance_by_name,
            device=device, batch_episodes=batch_episodes, rng=rng,
        )
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(policy.parameters(), float(bcfg.get("grad_clip", 1.0)))
        optimizer.step()
        row = {"epoch": epoch, **metrics}
        history.append(row)
        if epoch % log_every == 0:
            LOGGER.info(
                "BC epoch %d | loss=%.4f node_acc=%.3f charge_acc=%.3f depot_acc=%.3f",
                epoch, metrics.get("bc_loss", 0), metrics.get("node_accuracy", 0),
                metrics.get("charge_accuracy", 0), metrics.get("depot_accuracy", 0),
            )
        if metrics.get("bc_loss", 1e9) < best_val:
            best_val = float(metrics["bc_loss"])
            torch.save({
                "architecture_version": getattr(
                    __import__("src.models.feature_specs", fromlist=["ARCHITECTURE_VERSION"]),
                    "ARCHITECTURE_VERSION",
                    "exact_smdp_dynamic_v1",
                ),
                "model_state": policy.state_dict(),
                "model_config": config["model"],
                "charging_portions": portions,
                "bc_epoch": epoch,
                "bc_metrics": metrics,
            }, best_path)
            LOGGER.info("Saved best BC policy → %s", best_path)

    # Final + last checkpoint
    last_path = out_dir / "rc21_last_policy.pt"
    torch.save({
        "architecture_version": "exact_smdp_dynamic_v1",
        "model_state": policy.state_dict(),
        "model_config": config["model"],
        "charging_portions": portions,
        "bc_epoch": epochs - 1,
    }, last_path)

    policy = load_policy(best_path, device=device)
    eval_report = evaluate_bc_policy(config, policy, device)
    summary = {
        "best_bc_loss": best_val,
        "best_checkpoint": str(best_path),
        "last_checkpoint": str(last_path),
        "history": history,
        "greedy_eval": eval_report,
    }
    (out_dir / "bc_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    LOGGER.info("BC complete. Best checkpoint: %s", best_path)
    return summary


def bc_coef_at_update(rl_cfg_dict: dict, update_idx: int) -> float:
    """Linear decay of BC regularization coefficient."""
    raw = (rl_cfg_dict.get("bc_regularization") or {})
    if not bool(raw.get("enabled", False)):
        return 0.0
    c0 = float(raw.get("coefficient_initial", 0.1))
    c1 = float(raw.get("coefficient_final", 0.0))
    decay = max(int(raw.get("decay_updates", 200)), 1)
    t = min(max(int(update_idx), 0), decay) / float(decay)
    return float(c0 + (c1 - c0) * t)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Behavior-clone Transformer actor from expert demos.")
    p.add_argument("--config", type=str, default="configs/bc_RC21.yaml")
    p.add_argument("--device", type=str, default=None)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    if args.device is not None:
        config["device"] = args.device
    train_behavior_cloning(config)


if __name__ == "__main__":
    main()
